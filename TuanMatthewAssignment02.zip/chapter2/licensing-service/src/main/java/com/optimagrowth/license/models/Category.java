package com.optimagrowth.license.models;

public enum Category {
    SPORTS, FITNESS, ARTS, LITERATURE
}
